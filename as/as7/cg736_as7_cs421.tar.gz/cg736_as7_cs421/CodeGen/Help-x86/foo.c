main() {
  printf ("%d \n",f(3));
}

int g ()
{
return 4
;
}
